﻿'Name:          Andrew Rocha
'ID:            100590342
'Date Created:  January 20th, 2019
'Purpose:       Lab 1 - Average Units Shipped
'Description:   Your solution will take an input for each day in the week numbered
'               from 1 To 7. The user input data will need To be validated And, If it
'               passes validation, the data will need To be displayed To the user.
'               Once the number Of units has been entered For the 7​th​ day the solution
'               will calculate And display the average To the user.  
'

Option Strict On
Public Class frmAverageUnitsShipped

    Const MINIMUM_UNITS As Integer = 0 ' Minimum amount of units user must enter '
    Const MAXIMUM_UNITS As Integer = 1000 ' Maximum amount of units user must enter '
    Const MAXIMUM_DAYS As Integer = 7 ' Maximum amount of days in the week '


    Dim userInput As String = String.Empty ' User input taken and stored into this variable '
    Dim unitsArray(MAXIMUM_DAYS - 1) As Integer ' Array to store all values through week '
    Dim unitValue As Integer ' The value of the unit entered '
    Dim total As Double ' Total sum of all units '
    Dim day As Integer = 1 ' The day counter '
    Dim average As Double ' Average of the units in the week '

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click

        ' Ends the program '
        Application.Exit()

    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click

        ' Clear the textboxes when hit reset '
        txtUserInput.Clear()
        txtDisplayUnits.Clear()

        ' Reset the label to its default value (which is nothing) '
        lblAverageUnits.ResetText()

        ' Set focus back on the user input textbox to start over '
        txtUserInput.Focus()

        ' Enable the enter button for user to enter in the units '
        btnEnter.Enabled = True

        ' Enable the textbox for user to type in units '
        txtUserInput.ReadOnly = False

        ' Set all values back to its original state '
        day = 1
        total = 0
        average = 0
        unitValue = 0
        userInput = String.Empty
        lblDays.Text = "Day 1"


    End Sub

    Private Sub frmAverageUnitsShipped_Load(sender As Object, e As EventArgs) Handles MyBase.Load



    End Sub

    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click
        ' Set userInput variable to what text is in the user input textbox '
        userInput = txtUserInput.Text

        ' Check to see if user input is an integer '
        If (Integer.TryParse(userInput, unitValue)) Then

            ' Check to see if user input is within the correct range '
            If unitValue >= MINIMUM_UNITS And unitValue <= MAXIMUM_UNITS Then

                ' Store input into the array '
                unitsArray(day - 1) = unitValue

                ' Text from the user input textbox will be displayed in the txtDisplayUnits textbox '
                txtDisplayUnits.Text += txtUserInput.Text & vbCrLf

                ' Check if the day counter is less than 7
                If day < MAXIMUM_DAYS Then

                    ' Add another day to the counter '
                    day += 1

                    ' Go to the next day on the label '
                    lblDays.Text = "Day " & day.ToString()

                    ' Clear the user input textbox then focus on it so user can type in next value '
                    txtUserInput.Clear()
                    txtUserInput.Focus()

                Else

                    ' Calculate the total some of all units from the array '
                    For counter As Integer = 0 To unitsArray.Length - 1
                        total += unitsArray(counter)
                    Next

                    ' Set the enter button unable to click '
                    btnEnter.Enabled = False
                    ' Set the user input textbox to ReadOnly mode '
                    txtUserInput.ReadOnly = True
                    ' Clear the user input textbox '
                    txtUserInput.Clear()

                    ' Calculate average by dividing the sum from the maximum days '
                    average = total / MAXIMUM_DAYS
                    ' Display the average on the output label '
                    lblAverageUnits.Text = "Average per day: " & FormatNumber(average.ToString, 2)

                    ' Set the focus on the reset button to start a new week of units '
                    btnReset.Focus()
                End If

            Else
                ' Prompt user to enter a new number within the range of 0 to 1000'
                MessageBox.Show("Please enter a whole number between " & MINIMUM_UNITS.ToString() & " and " & MAXIMUM_UNITS.ToString())
                txtUserInput.Clear()
                txtUserInput.Focus()

            End If

        Else
            ' Prompt user to enter a new numeric whole value and let user try again'
            MessageBox.Show("Please enter an integer/whole number")
            txtUserInput.Clear()
            txtUserInput.Focus()

        End If

    End Sub

    Private Sub txtUserInput_TextChanged(sender As Object, e As EventArgs) Handles txtUserInput.TextChanged



    End Sub

    Private Sub lblDays_Click(sender As Object, e As EventArgs) Handles lblDays.Click


    End Sub

    Private Sub btnReset_KeyDown(sender As Object, e As KeyEventArgs)
    End Sub
End Class
