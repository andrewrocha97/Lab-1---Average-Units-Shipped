﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAverageUnitsShipped
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblUnits = New System.Windows.Forms.Label()
        Me.txtUserInput = New System.Windows.Forms.TextBox()
        Me.lblDays = New System.Windows.Forms.Label()
        Me.lblAverageUnits = New System.Windows.Forms.Label()
        Me.btnEnter = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.tooltip = New System.Windows.Forms.ToolTip(Me.components)
        Me.txtDisplayUnits = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'lblUnits
        '
        Me.lblUnits.Location = New System.Drawing.Point(38, 16)
        Me.lblUnits.Name = "lblUnits"
        Me.lblUnits.Size = New System.Drawing.Size(34, 13)
        Me.lblUnits.TabIndex = 0
        Me.lblUnits.Text = "&Units:"
        Me.lblUnits.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtUserInput
        '
        Me.txtUserInput.Location = New System.Drawing.Point(78, 13)
        Me.txtUserInput.Name = "txtUserInput"
        Me.txtUserInput.Size = New System.Drawing.Size(114, 20)
        Me.txtUserInput.TabIndex = 1
        Me.tooltip.SetToolTip(Me.txtUserInput, "Enter units here")
        '
        'lblDays
        '
        Me.lblDays.Location = New System.Drawing.Point(198, 16)
        Me.lblDays.Name = "lblDays"
        Me.lblDays.Size = New System.Drawing.Size(35, 13)
        Me.lblDays.TabIndex = 2
        Me.lblDays.Text = "&Day 1"
        Me.lblDays.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblAverageUnits
        '
        Me.lblAverageUnits.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAverageUnits.Location = New System.Drawing.Point(41, 201)
        Me.lblAverageUnits.Name = "lblAverageUnits"
        Me.lblAverageUnits.Size = New System.Drawing.Size(193, 23)
        Me.lblAverageUnits.TabIndex = 4
        Me.lblAverageUnits.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.tooltip.SetToolTip(Me.lblAverageUnits, "The Average of units shipped will be displayed here")
        '
        'btnEnter
        '
        Me.btnEnter.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.btnEnter.Location = New System.Drawing.Point(12, 236)
        Me.btnEnter.Name = "btnEnter"
        Me.btnEnter.Size = New System.Drawing.Size(79, 28)
        Me.btnEnter.TabIndex = 5
        Me.btnEnter.Text = "&Enter"
        Me.tooltip.SetToolTip(Me.btnEnter, "Click to Enter amount of units for each day")
        Me.btnEnter.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.DialogResult = System.Windows.Forms.DialogResult.Retry
        Me.btnReset.Location = New System.Drawing.Point(97, 236)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(79, 28)
        Me.btnReset.TabIndex = 6
        Me.btnReset.Text = "&Reset"
        Me.tooltip.SetToolTip(Me.btnReset, "Click to Reset program")
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnExit.Location = New System.Drawing.Point(182, 236)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(79, 28)
        Me.btnExit.TabIndex = 7
        Me.btnExit.Text = "E&xit"
        Me.tooltip.SetToolTip(Me.btnExit, "Click to Exit out of program")
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'txtDisplayUnits
        '
        Me.txtDisplayUnits.BackColor = System.Drawing.SystemColors.Window
        Me.txtDisplayUnits.Location = New System.Drawing.Point(41, 44)
        Me.txtDisplayUnits.Multiline = True
        Me.txtDisplayUnits.Name = "txtDisplayUnits"
        Me.txtDisplayUnits.ReadOnly = True
        Me.txtDisplayUnits.Size = New System.Drawing.Size(193, 154)
        Me.txtDisplayUnits.TabIndex = 3
        Me.tooltip.SetToolTip(Me.txtDisplayUnits, "Units entered will be displayed here")
        '
        'frmAverageUnitsShipped
        '
        Me.AcceptButton = Me.btnEnter
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnReset
        Me.ClientSize = New System.Drawing.Size(271, 276)
        Me.Controls.Add(Me.txtDisplayUnits)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnEnter)
        Me.Controls.Add(Me.lblAverageUnits)
        Me.Controls.Add(Me.lblDays)
        Me.Controls.Add(Me.txtUserInput)
        Me.Controls.Add(Me.lblUnits)
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(287, 315)
        Me.MinimizeBox = False
        Me.MinimumSize = New System.Drawing.Size(287, 315)
        Me.Name = "frmAverageUnitsShipped"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Average Units Shipped"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblUnits As Label
    Friend WithEvents txtUserInput As TextBox
    Friend WithEvents lblDays As Label
    Friend WithEvents lblAverageUnits As Label
    Friend WithEvents btnEnter As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents tooltip As ToolTip
    Friend WithEvents txtDisplayUnits As TextBox
End Class
